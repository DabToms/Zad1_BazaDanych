﻿namespace Factory;

partial class PopupAddCollumn
{
    /// <summary>
    ///  Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    ///  Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    ///  Required method for Designer support - do not modify
    ///  the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
            this.Add = new System.Windows.Forms.Button();
            this.TypeSelector = new System.Windows.Forms.ComboBox();
            this.Return = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(152, 89);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(75, 23);
            this.Add.TabIndex = 0;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // TypeSelector
            // 
            this.TypeSelector.FormattingEnabled = true;
            this.TypeSelector.Location = new System.Drawing.Point(41, 12);
            this.TypeSelector.Name = "TypeSelector";
            this.TypeSelector.Size = new System.Drawing.Size(186, 23);
            this.TypeSelector.TabIndex = 1;
            // 
            // Return
            // 
            this.Return.Location = new System.Drawing.Point(41, 89);
            this.Return.Name = "Return";
            this.Return.Size = new System.Drawing.Size(75, 23);
            this.Return.TabIndex = 2;
            this.Return.Text = "Return";
            this.Return.UseVisualStyleBackColor = true;
            this.Return.Click += new System.EventHandler(this.Return_Click);
            // 
            // PopupAddCollumn
            // 
            this.ClientSize = new System.Drawing.Size(273, 138);
            this.Controls.Add(this.Return);
            this.Controls.Add(this.TypeSelector);
            this.Controls.Add(this.Add);
            this.Name = "PopupAddCollumn";
            this.ResumeLayout(false);
    }

    #endregion

    private Button Add;
    private ComboBox TypeSelector;
    private Button Return;
}