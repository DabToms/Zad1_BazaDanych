using Factory.Core;

namespace Factory;

public partial class MainProgram : Form
{
    private readonly Database database = new Database();

    public MainProgram()
    {
        InitializeComponent();
    }

    private void AddRow_Click(object sender, EventArgs e)
    {
        database.addRow();
        this.ReloadTable();
    }

    private void AddCollumn_Click(object sender, EventArgs e)
    {
        database.addCol();
        var formPopup = new PopupAddCollumn();
        formPopup.ShowDialog(this);

        this.ReloadTable();
    }

    private void Clear_Click(object sender, EventArgs e)
    {
        DataBox.Items.Clear();
        this.ClearTable();
    }

    private void ReloadTable()
    {

    }
    private void ClearTable()
    {

    }
}
